from django.db import models


class PersonalInfo(models.Model):
    full_name = models.CharField(max_length=255)
    height = models.IntegerField()
    weight = models.IntegerField()
    age = models.IntegerField()
