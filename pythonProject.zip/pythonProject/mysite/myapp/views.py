from django.shortcuts import render
from .models import PersonalInfo

def index(request):
    return render(request, 'index.html', {'info': PersonalInfo.objects.first()})

def about(request):
    info = PersonalInfo.objects.first()
    return render(request, 'about.html', {'info': info})

def contacts(request):
    contact_data = {
        'phone': '123-456-7890',
        'email': 'example@email.com',
        'social_media': 'your_social_media_link',
    }
    return render(request, 'contacts.html', {'contact_data': contact_data})